import random
# Defination of Sample Variables
first_name = ["Thomas", "Stella", "Rose", "Emmanuel", "Raphael", "Christine", "Leah"]
last_name = ["Baguma", "Kemigisa", "Kabacubya", "Mpagi", "Mugisa", "Ajuma", "Waiwala"]
Gender = ["Female", "Male"]
# Creating List of atleast 400 Workers
Employees = []
num_employees = 400
for i in range(num_employees):
    employee_first_name = random.choice(first_name)
    employee_last_name = random.choice(last_name)
    employee_gender = random.choice(Gender)
    employee_salary = random.randint(5000,40000) #Generate Random Salary within specified range
    Employee_ID = f"E{i+1:03}" # Padding IDs with zeros, e.g., E001, E002
    Employees.append({"id": Employee_ID, "sex":employee_gender, "name": f"{employee_first_name} {employee_last_name}", "Salary": employee_salary})
print(Employees)




# Assigning Employee Level
for employee in Employees:
    try: # Handle potential exceptions
        employee_salary = employee["Salary"] # Retrieve Salary from the employee dictionary
        employee_gender = employee["sex"] # Retrieve gender from the employee dictionary
    except KeyError as e:
        print(f"missing key in employee data: {e}")
        continue
    finally:
        if 10000 < employee_salary < 20000:
            employee_level = "A1"
        elif 7500 < employee_salary < 30000 and employee_gender == "Female":
            employee_level = "A5-F"
        else:
            employee_level = "A0" # Set default Employee Level
    # Generating Payment Slip
    line_seperator = "=" * 40
    payment_slip = (
    f"{line_seperator}\n" 
    f"{'HIGHRIDGE CONSTRTUCTION COMPANY':^20}\n"
    f"{'PAYMENT SLIP':^30}\n"
    f"{'-' * 40}\n" 
    f"Employee ID: {employee['id']}\n"
    f"Employee Name: {employee['name']}\n"
    f"Employee Gender: {employee['sex']}\n"
    f"Employee Salary: ${employee['Salary']:,}\n"
    f"Employee Level:{employee_level}\n"
    f"{line_seperator}\n"
    )
    print(payment_slip)