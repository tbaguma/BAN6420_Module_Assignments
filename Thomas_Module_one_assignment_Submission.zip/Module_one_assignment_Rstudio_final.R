# Load required library
library(dplyr)
library(stringr)

# Definition of sample variables
first_name <- c("Thomas", "Stella", "Rose", "Emmanuel", "Raphael", "Christine", "Leah")
last_name <- c("Baguma", "Kemigisa", "Kabacubya", "Mpagi", "Mugisa", "Ajuma", "Waiwala")
Gender <- c("Female", "Male")

# Creating a list of at least 400 Workers
set.seed(123) # to ensure reproducibility
num_employees <- 400

Employees <- data.frame(
  id = sprintf("E%03d", 1:num_employees), # Generate employee IDs e.g., E001, E002
  sex = sample(Gender, num_employees, replace = TRUE), # Random Gender
  name = paste(
    sample(first_name, num_employees, replace = TRUE),
    sample(last_name, num_employees, replace = TRUE)
  ), # Random Name
  Salary = sample(5000:40000, num_employees, replace = TRUE) # Random Salary
)

# Assigning Employee Level
for (i in 1:num_employees) {
  if (Employees$Salary[i] > 10000 & Employees$Salary[i] < 20000) {
    Employees$level[i] <- "A1"
  } else if (Employees$Salary[i] > 7500 & Employees$Salary[i] < 30000 & Employees$sex[i] == "Female") {
    Employees$level[i] <- "A5-F"
  } else {
    Employees$level[i] <- "A0"
  }
}

# Generate Payment Slips
generate_payment_slip <- function(employee) {
  tryCatch({
    paste(
      "Highridge Construction Company",
      "Payment Slip",
      paste("Employee ID:", employee["id"]),
      paste("Name:", employee["name"]),
      paste("Gender:", employee["sex"]),
      paste("Salary:", employee["Salary"]),
      paste("Level:", employee["level"]),
      sep = "\n"
    )
  }, error = function(e) {
    message("Error generating payment slip for employee: ", employee["id"])
    message("Error details: ", e$message)
    return(NULL)
  })
}

# Print Payment Slips
cat(apply(Employees, 1, generate_payment_slip), sep = "\n\n")

