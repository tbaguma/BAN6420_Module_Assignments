from flask import Flask, render_template, request, jsonify, redirect, url_for
from pymongo import MongoClient
import logging
from faker import Faker
import random
import os
import csv

# Initialize Flask app
app = Flask(__name__)

# Configure logging
logging.basicConfig(level=logging.INFO)

# MongoDB connection
try:
    client = MongoClient("mongodb://localhost:27017/")
    client.admin.command('ping')  # Test the MongoDB connection
    logging.info("Successfully connected to MongoDB.")
except Exception as e:
    logging.error("Failed to connect to MongoDB.")
    raise RuntimeError("Could not connect to MongoDB.") from e

# Database and collection setup
db = client["user_data"]
collection = db["survey_responses"]

# Initialize Faker instance
fake = Faker()

class User:
    """A class to represent a user and their survey data."""

    def __init__(self, name, age, gender, income, expenses):
        self.name = name
        self.age = age
        self.gender = gender
        self.income = income
        self.expenses = expenses

    @classmethod
    def from_form(cls, form_data):
        """Create a User instance from form data."""
        try:
            # Retrieve basic user information
            name = form_data.get('name', 'Unknown')  # Default to 'Unknown' if name is missing
            age = form_data.get('age', '0')
            gender = form_data.get('gender', 'Unspecified')  # Default to 'Unspecified'
            income = form_data.get('income', '0.0')

            # Ensure age and income are valid numbers
            try:
                age = int(age)
            except ValueError:
                raise ValueError("Age must be a valid number.")
            
            try:
                income = float(income)
            except ValueError:
                raise ValueError("Income must be a valid number.")

            # Initialize expenses
            expenses = []

            # List of possible expense categories
            expense_categories = ['utilities', 'entertainment', 'schoolFees', 'shopping', 'healthcare']
            
            # Process expenses based on checkboxes and their associated amounts
            for category in expense_categories:
                if form_data.get(category):  # Checkbox is checked
                    amount_key = f"{category}Amount"
                    amount = form_data.get(amount_key, '').strip()  # Retrieve the amount as a string
                    if amount:  # If an amount is provided
                        try:
                            expenses.append({'category': category, 'amount': float(amount)})
                        except ValueError:
                            raise ValueError(f"Invalid amount for {category}.")

            # Return the constructed User instance
            return cls(name, age, gender, income, expenses)

        except ValueError as ve:
            raise ValueError(f"Invalid data in form submission: {ve}")
        except Exception as e:
            raise RuntimeError(f"An error occurred while creating the user: {e}")

    def to_dict(self):
        """Convert the User instance to a dictionary."""
        return {
            'name': self.name,
            'age': self.age,
            'gender': self.gender,
            'income': self.income,
            'expenses': self.expenses
        }


# Function to generate random survey response
def generate_random_response():
    name = fake.name()
    age = random.randint(18, 80)
    gender = random.choice(['Male', 'Female'])
    income = round(random.uniform(20000, 120000), 2)
    
    expense_categories = ['utilities', 'entertainment', 'schoolFees', 'shopping', 'healthcare']
    expenses = []
    
    # Randomly choose some expense categories to populate
    for category in expense_categories:
        if random.choice([True, False]):  # Randomly decide if the user has this expense
            amount = round(random.uniform(50, 1000), 2)
            expenses.append({'category': category, 'amount': amount})

    return User(name, age, gender, income, expenses)

# Function to generate bulk random survey responses
def generate_bulk_responses(number_of_responses):
    users = []
    for _ in range(number_of_responses):
        user = generate_random_response()
        users.append(user.to_dict())
    return users

@app.route('/')
def index():
    return render_template('survey_form.html')

@app.route('/', methods=['POST'])
def survey():
    try:
        # Collect and validate form data
        user = User.from_form(request.form)

        # Store data in MongoDB
        collection.insert_one(user.to_dict())
        logging.info("Survey response successfully saved to MongoDB.")

        return redirect(url_for('thank_you'))
    except Exception as e:
        logging.error(f"An error occurred: {e}")
        return "An error occurred while processing your response. Please try again."

@app.route('/thank_you')
def thank_you():
    return "<h1>Thank you for your response! Your data has been submitted successfully.</h1>"

@app.route('/export_to_csv', methods=['GET'])
def export_to_csv():
    try:
        # Retrieve all data from the collection
        data = list(collection.find({}))

        # Define the CSV file name and path
        file_path = os.path.join(os.getcwd(), 'exported_data.csv')

        # Extract unique expense categories
        categories = set(exp['category'] for doc in data for exp in doc.get('expenses', []))

        # Specify fieldnames
        fieldnames = ['name', 'age', 'gender', 'income'] + sorted(categories)

        # Write data to CSV
        with open(file_path, 'w', newline='', encoding='utf-8') as csv_file:
            writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
            writer.writeheader()

            for doc in data:
                expenses = {cat: '' for cat in categories}
                for exp in doc.get('expenses', []):
                    expenses[exp['category']] = exp['amount']

                row = {
                    'name': doc.get('name'),
                    'age': doc.get('age'),
                    'gender': doc.get('gender'),
                    'income': doc.get('income'),
                    **expenses
                }
                writer.writerow(row)

        logging.info("Data exported to CSV successfully.")
        return jsonify({'message': f"Data exported successfully to {file_path}"}), 200
    except Exception as e:
        logging.error(f"Export failed: {e}")
        return jsonify({'message': 'Export failed. Please try again later.'}), 500

# Endpoint to generate a single random response
@app.route('/generate_random_response', methods=['GET'])
def generate_random():
    user = generate_random_response()
    collection.insert_one(user.to_dict())
    logging.info("Random survey response generated and saved to MongoDB.")
    return jsonify({'message': 'Random survey response generated and saved to MongoDB.'})

# Endpoint to generate multiple random responses (bulk)
@app.route('/generate_bulk_responses', methods=['GET'])
def generate_bulk():
    try:
        number_of_responses = int(request.args.get('count', 10))  # Default to 10 responses
        users = generate_bulk_responses(number_of_responses)
        collection.insert_many(users)
        logging.info(f"{number_of_responses} random survey responses generated and saved to MongoDB.")
        return jsonify({'message': f'{number_of_responses} random survey responses generated and saved to MongoDB.'})
    except ValueError:
        return jsonify({'message': 'Invalid count parameter. Please provide a valid number.'}), 400

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80)
