##1 Flask web application for data collection

** Overview - This project is a Flask-based web application that collects and manages survey responses. It supports user data storage in MongoDB, dynamic form submissions, and features such as random survey data generation and exporting survey data to a CSV file.

** Features
(a) User Survey Form:
- Collects user information (name, age, gender, income).
- Allows input of expense details categorized by utilities, entertainment, school fees, shopping, and healthcare.
(b) Data Persistence:
- Stores survey responses in a MongoDB database.
(c) Random Data Generation:
- Generates single or bulk survey responses with random data for testing.
(d) Export to CSV:
- Exports all survey responses from the database into a CSV file.
(e) Dynamic Routing:
- Includes routes for form submission, viewing a "Thank You" page, and API endpoints for managing survey data.


** Prerequisites
Software Requirements
(i) Python 3.8+
(ii) MongoDB (Running locally on localhost:27017)
(iii) Pip (Python package manager)

** Python Libraries
(a) Flask: Purpose: Web framework used to build web applications. It provides tools to create routes, handle requests, and render templates.
Specific Imports:
- Flask: Creates and manages the Flask application instance.
- render_template: Renders HTML templates for the front-end.
- request: Handles incoming HTTP requests and provides access to form data and query parameters.
- jsonify: Converts Python dictionaries into JSON responses for APIs.
- redirect: Redirects users to another route.
- url_for: Dynamically generates URLs for specific routes.

(b) pymongo: A Python driver for MongoDB, enabling database operations.
Specific Imports:
- MongoClient: Establishes a connection to the MongoDB server.

(c) logging: A built-in Python library for logging messages. It’s used to track application events, errors, and debugging information.

(d) Faker: A library to generate fake data. It's useful for testing and creating sample data.

(e) random: A built-in Python library for generating random numbers and making random selections. It’s used here to randomize survey responses and expenses.

(f) os: A built-in Python library for interacting with the operating system. It's used to construct file paths and access environment variables.

(g) csv: A built-in Python library for reading and writing CSV files. It’s used here to export survey responses from the MongoDB collection into a CSV format.


Install required dependencies with:

- pip install flask
- pip install pymongo
- pip install faker


** Endpoints

(1) Web Routes
/ (GET): Displays the survey form.
/ (POST): Handles form submission and stores data in MongoDB.
/thank_you (GET): Displays a "Thank You" page upon successful form submission.

(2) API Endpoints
/generate_random_response (GET): Generates and stores a random survey response in MongoDB.
/generate_bulk_responses (GET): Accepts a count query parameter to generate multiple random survey responses.
/export_to_csv (GET): Exports all survey data to a CSV file saved in the application's root directory.


** Code Breakdown
Main Modules

(A) User Class: Encapsulates user data and validation.
Methods:
from_form: Parses and validates form data.
to_dict: Converts the User instance into a dictionary format.

(B) Random Response Generation:
Functions:
generate_random_response: Generates a single randomized survey response.
generate_bulk_responses: Generates multiple random responses.

(C) MongoDB Integration: Stores survey responses in the survey_responses collection of the user_data database.

(D) Export to CSV: Dynamically generates a CSV file based on survey data in MongoDB.

(E) Error Handling
- Detailed logging using Python's logging module.
- Error handling for invalid input and database connectivity issues.

** Example Usage
- Access the application at http://127.0.0.1:5000/.
- Fill out the form and submit.
- To Generate 1 random response, Access the /generate_random_response endpoint vide: http://127.0.0.1:5000//generate_random_response
- To Generate 10 random responses, Access the /generate_bulk_responses endpoint vide: http://127.0.0.1:5000//generate_bulk_responses
- Export Data to CSV: Access the /export_to_csv endpoint vide: http://127.0.0.1:5000//export_to_csv



##2 Data Analysis and Visualization Script

** Overview: This Jupyter script performs a series of data analysis tasks on the CSV file generated and exported from the flask web application. It preprocesses the data, generates visualizations, and creates a PowerPoint presentation to summarize insights. 

** Required Python Libraries

- pandas: For data manipulation and analysis.
- os: To interact with the operating system.
- seaborn: For creating statistical visualizations.
- matplotlib: For plotting graphs.
- collections.Counter: To count occurrences of items.
- python-pptx: For generating PowerPoint presentations.

** Installation: Install the required libraries using pip:

- pip install pandas matplotlib seaborn python-pptx

** Input File

The script processes a CSV file located at:

C:\Users\HP\Desktop\Thomas_project\survey_project\exported_data.csv

- Ensure the file exists at this location or update the file_path variable in the script with the correct path.

** Key Features

1. Data Preprocessing

- Missing Value Handling: Fills missing values in numeric columns with their respective column means.
- Duplicate Analysis: Identifies and reports duplicate rows in the dataset.
- Gender Standardization: Converts all gender labels to lowercase for consistency.

2. Data Visualization

- Top 10 Ages with Highest Income: Generates a bar plot to display the top 10 ages with the highest income.
- Saves the plot as Top 10 Ages with Highest Income.png.
- Gender Distribution Across Expense Categories: Creates a stacked bar chart showing gender-based expenditure across categories like entertainment, healthcare, school fees, shopping, and utilities.
- Saves the plot as Gender Distribution Across Expense Categories.png.

3. PowerPoint Presentation Generation

Adds two slides to a PowerPoint presentation:
- Slide 1: Displays the chart for the top 10 ages with the highest income.
- Slide 2: Displays the chart for gender distribution across expense categories.
- Saves the presentation as gender_distribution_analysis.pptx.

** Usage Instructions

a- Configure Input File Path: Update the file_path variable with the path to your dataset.
b- Run the Script: Execute the script using Python

** Output Files:

- Plots: Saved as PNG files in the script's directory.
- PowerPoint: Saved as gender_distribution_analysis.pptx in the script's directory.


##3 Hosting the Flask Application on AWS

The following steps were followed to host the Flask application on AWS
(a) Creation of an account on AWS and making necessary configurations such as creating an IAM role with necessary permissions.
(b) Launching an EC2 Instance: Log in to the AWS Management Console and launch a Windows Server EC2 instance
(c) Connecting to the Instance
(d) Open the Remote Desktop Connection tool on your computer.
(e) Set Up the Windows Server
	- Istall MongoDB
	- Install Python from python.org
	-Install required libraries using pip install flask pymongo
(f) Deploy Flask Application
	-Use the Remote Desktop Connection to copy your Flask app files to the server and place them in a directory (C:\Users\Administrator\project_app)
	-Navigate to the directory where app.py is located:"C:\Users\Administrator\survey_project"-
	-Run the application: "python app.py"
	-Test locally using "http://127.0.0.1:80"

(g) Make the Flask App Public
	-Modify app.run() in app.py to make the app accessible:"app.run(host='0.0.0.0', port=80)"
	-Restart the Flask app and access it via "http://13.60.156.238".

(h) Export CSV File
	- Access /export: Visit "http://13.60.156.238/export_to_csv" in your browser.
	-The survey_data.csv will be saved to the directory where the app is running.(Data exported to C:\Users\Administrator\project_app\survey_data.csv)

