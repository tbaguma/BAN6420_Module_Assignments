# Creation of Policy Holder Class
class PolicyHolder:
    def __init__(self, holder_id, name, age, email, status = "inactive"):
        self.holder_id = holder_id
        self.name = name
        self.age = age
        self.email = email
        self.status = status

    # Registering a policy Holder
    def register(self):
        self.status = "Active"
        print(f"PolicyHolder {self.name} (ID: {self.holder_id}) Registered. Status: {self.status}")

    # Suspending a Policy Holder
    def suspend(self):
        self.status = "Suspended"
        print(f"PolicyHolder {self.name} (ID: {self.holder_id}) Suspended. Status: {self.status}")
    
    # Reactivating a Policy Holder
    def reactivate(self):
        self.status = "Active"
        print(f"PolicyHolder {self.name} (ID: {self.holder_id}) Reactivated. Status: {self.status}")
    
    # Display Policy Holder Status
    def display_details(self):
        return f"ID: {self.holder_id }, name: {self.name}, age: {self.age} email: {self.email} status: {self.status}"