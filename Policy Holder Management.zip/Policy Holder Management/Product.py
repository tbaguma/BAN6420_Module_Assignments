# Creating Insurance Product Class
class Product:
    def __init__(self, product_id, product_name, product_price, status = "created"):
        self.product_id = product_id
        self.product_name = product_name
        self.product_price = product_price
        self.status = status

   # Creating a product
    def create_product(self):
        self.status = "created"
        print(f"Product {self.product_id} created: {self.product_name} price: £{self.product_price}")

    # Updating a product
    def update_product(self, product_name=None, product_price=None):
        if product_name:
            self.product_name = product_name
        if product_price is not None:
            self.product_price = product_price
        print(f"Product {self.product_id} updated: {self.product_name} price: £{self.product_price}")

    # Suspending a product
    def suspend_product(self):
        self.status = "suspended"
        print(f"Product {self.product_id} suspended.")
    
    # Display Product Status
    def display_product(self):
        return f"ID: {self.product_id }, name: { self.product_name}, Price: {self.product_price}, Status: {self.status}"