import PolicyHolder
import Product
import Payment

# Creating Policy Holders
policyholder_1 = PolicyHolder.PolicyHolder(holder_id="P001", name="Thomas Baguma", age=33, email="tbaguma@insurance.com")
policyholder_2 = PolicyHolder.PolicyHolder(holder_id="P002", name="Lea Waiwala", age=30, email="lwaiwala@insurance.com")
policyholder_3 = PolicyHolder.PolicyHolder(holder_id="P003", name="Ralph Mugisa", age=25, email="rmugisa@insurance.com")


# Creating Products
product_1 = Product.Product(product_id=101, product_name="Medical", product_price=20000)
product_2 = Product.Product(product_id=102, product_name="Life", product_price=50000)
product_3 = Product.Product(product_id=103, product_name="Property", product_price=30000)


# Creating Payments
payment_1 = Payment.Payment(reference_id="P00100", holder_id=policyholder_1.holder_id, product_id=product_1.product_id, amount=20000)
payment_2 = Payment.Payment(reference_id="P00101", holder_id=policyholder_2.holder_id, product_id=product_2.product_id, amount=50000)
payment_3 = Payment.Payment(reference_id="P00102", holder_id=policyholder_3.holder_id, product_id=product_3.product_id, amount=30000)


# Register Policy Holder
policyholder_1.register()
policyholder_2.register()
policyholder_3.register()

# Processing Payments
payment_1.process_payment()
payment_2.process_payment()
payment_3.process_payment()

# Display Account Details
def account_details(policyholder, product, Payment):
    print("="*90)
    print("Policyholder Details:")
    print(policyholder.display_details())
    print("\nProduct Details:")
    print(product.display_product())
    print("\nPayment Details:")
    print(Payment.display_payment())
    print("="*90)


account_details(policyholder_1, product_1, payment_1)
account_details(policyholder_2, product_2, payment_2)
account_details(policyholder_3, product_3, payment_3)