# Creating Payment Class
class Payment:
    def __init__(self, reference_id, holder_id, product_id, amount, status = "completed"):
        self.reference_id = reference_id
        self.holder_id = holder_id
        self.product_id = product_id
        self.amount = amount        
        self.status = status
    # Processing Payment
    def process_payment(self):
        self.status = "completed"
        print(f"Payment: {self.reference_id} Prossesed")

    # Generating Payment reminders
    def payment_reminder(self):
        if self.status == "pending":
            print(f"Reminder: Payment {self.reference_id} Pending")

    # Generating Penalty Charge
    def charge_penalty(self, penalty_amount = 1000):
        if self.status == "pending":
            self.amount += penalty_amount
            print(f"Penalty of {penalty_amount} charged for Payment {self.reference_id}. New amount: {self.amount}")  

    # Displaying Payment status
    def display_payment(self):
        return f"Ref: {self.reference_id}, Holder: {self.holder_id}, Product: {self.product_id}, amount: { self.amount}, Status: {self.status}"