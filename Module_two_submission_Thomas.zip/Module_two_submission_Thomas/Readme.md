Employee Data Processing and Profile Management Scripts:

This project comprises two scripts for managing employee profile data stored in CSV files:

** Python Script: Uses the Jupyter Notebook to Process salaries and exports individual employee profiles.
** R Script: Unzips, reads, and displays employee profile data from compressed CSV files.## Features



#*#*#*Python Script:

** Features:
 
1. Extract and Read Data
   - Extracts a CSV file from a ZIP archive.
   - Loads the CSV file into a pandas DataFrame for processing.

2. Retrieve Employee Details
   - Searches for an employee by name
   - Returns details of the employee

3. Generate Salary Dictionary
   - Creates a dictionary for all employees with their salary details

4. Export Employee Profiles
   - Exports an individual employee’s details to a CSV file.
   - Compresses the exported file into a ZIP archive.

5. Error Handling
   - Handles cases where employee details are not found.
   - Ensures cleanup of temporary files after exporting.


** Prerequisites

1. Python Libraries
   - pandas
   - zipfile
   - os

2. Dataset
   - A ZIP file containing the CSV file (`Total.csv`)

** Usage

a) Set File Path:
- Update the file_path variable with the location of the ZIP file containing the CSV file.

b) Run the Script:
Execute the script to extract, process, and export employee details.

c) Sample Use
- Use the code to Export_Employee_Profile for ("PATRICK GARDNER")

- For any other Employee, change Sample_employee_name variable accordingly
d) View Employee Salary Details:
- Access the generated salary dictionary

e) Export Employee Profile

- Export a specific employee’s details to a ZIP file:
- The exported profile will be saved in the `Employee Profile.zip` archive.



#*#*#* R Script: 

** Features:
- Defines paths for the ZIP file and the destination directory.
- File Existence Check
- Automatically extracts the content of a ZIP file.
- CSV File Handling
- Error Handling
- Data Preview


** Prerequisites
1. R Installation:
- Ensure that R is installed on your system.

2. Required Package:
- The script uses the utils library, which is included by default in base R.

3. Input File:
- A ZIP file containing one or more CSV files.

** Usage

Set the ZIP File Path:
- Update the zip_file variable with the path to your ZIP file.

Run the Script:
- Execute the script in your R environment.

Review Output:

- The script will display the contents of each CSV file found in the ZIP archive.


## Author

Name: [Baguma Thomas]

