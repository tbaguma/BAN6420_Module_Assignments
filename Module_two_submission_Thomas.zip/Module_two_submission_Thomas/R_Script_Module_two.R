library(utils)

# Set paths
zip_file <- "C:/Users/tbaguma/Documents/Employee Profile.zip"
extracted_dir <- extracted_dir <- sub("\\.zip$", "", zip_file)

# Check file existence
if (!file.exists(zip_file)) {
  stop("ZIP file does not exist. Check the path and try again.")
}

# Unzip files
unzip(zip_file, exdir = extracted_dir)

# Get CSV files
csv_files <- list.files(extracted_dir, pattern = "\\.csv$")

# Read and display data
if (length(csv_files) > 0) {
  data_list <- lapply(csv_files, function(file) {
    tryCatch({
      read.csv(file.path(extracted_dir, file))
    }, error = function(e) {
      cat(paste("Error reading", file, ": ", e$message, "\n"))
      NULL
    })
  })
  
  for (i in seq_along(data_list)) {
    if (!is.null(data_list[[i]])) {
      cat(paste("Contents of", csv_files[i], ":\n"))
      print(head(data_list[[i]]))
    }
  }
} else {
  cat("No CSV files found in the extracted directory.\n")
}