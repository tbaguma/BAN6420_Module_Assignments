import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score

# -------------------------------
# Load Data
# -------------------------------
def load_data(csv_path):
    try:
        df = pd.read_csv(csv_path)
        print(f"Data loaded successfully. Shape: {df.shape}")
        return df
    except Exception as e:
        print("Error loading CSV file:", e)
        return None

# -------------------------------
# EDA
# -------------------------------
def perform_eda(df):
    print("\n--- Exploratory Data Analysis (EDA) ---")
    print(f"Shape: {df.shape}")
    print("\nData Types:\n", df.dtypes)

    duplicate_count = df.duplicated().sum()
    print(f"\nDuplicate Rows: {duplicate_count}")
    if duplicate_count > 0:
        df.drop_duplicates(inplace=True)
        print(f"Dropped {duplicate_count} duplicates. New shape: {df.shape}")

    missing = df.isnull().sum()
    if missing.any():
        print("\nMissing Values (Top 10):\n", missing[missing > 0].sort_values(ascending=False).head(10))
    else:
        print("\nNo missing values.")

    print("\nSummary Statistics:\n", df.describe().T)

    numeric_df = df.select_dtypes(include=[np.number])
    if not numeric_df.empty:
        plt.figure(figsize=(10, 8))
        sns.heatmap(numeric_df.corr(), annot=False, cmap='coolwarm')
        plt.title("Correlation Heatmap")
        plt.tight_layout()
        plt.show()

# -------------------------------
# Preprocessing
# -------------------------------
def preprocess_data(df):
    threshold = len(df) * 0.5
    dropped_columns = df.columns[df.isnull().sum() > threshold].tolist()
    df = df.drop(columns=dropped_columns)
    print(f"\nDropped columns with >50% missing values: {dropped_columns}")

    df_numeric = df.select_dtypes(include=[np.number])
    df_numeric = df_numeric.fillna(df_numeric.mean())

    if df_numeric.empty:
        print("No numeric data available after preprocessing.")
        return [], np.array([]), pd.DataFrame()

    scaler = StandardScaler()
    df_scaled = scaler.fit_transform(df_numeric)

    print(f"Preprocessed data shape: {df_numeric.shape}")
    return df_numeric.columns.tolist(), df_scaled, df_numeric

# -------------------------------
# K-Means Clustering
# -------------------------------
def apply_kmeans(data, k=3):
    model = KMeans(n_clusters=k, n_init=10, random_state=42)
    labels = model.fit_predict(data)
    return model, labels

# -------------------------------
# Elbow Plot
# -------------------------------
def elbow_plot(data, max_k=10):
    inertias = []
    for k in range(1, max_k + 1):
        model = KMeans(n_clusters=k, n_init=10, random_state=42)
        model.fit(data)
        inertias.append(model.inertia_)

    plt.figure(figsize=(8, 4))
    plt.plot(range(1, max_k + 1), inertias, marker='o')
    plt.title('Elbow Method for Optimal k')
    plt.xlabel('Number of Clusters (k)')
    plt.ylabel('Inertia')
    plt.grid(True)
    plt.tight_layout()
    plt.show()

# -------------------------------
# Visualize Clusters
# -------------------------------
def visualize_clusters(data_scaled, labels, sample_size=3000):
    if len(data_scaled) > sample_size:
        indices = np.random.choice(len(data_scaled), sample_size, replace=False)
        data_scaled = data_scaled[indices]
        labels = np.array(labels)[indices]

    pca = PCA(n_components=2)
    reduced_data = pca.fit_transform(data_scaled)

    df_plot = pd.DataFrame(reduced_data, columns=["PC1", "PC2"])
    df_plot['Cluster'] = labels

    plt.figure(figsize=(8, 6))
    sns.scatterplot(data=df_plot, x="PC1", y="PC2", hue="Cluster", palette="Set1")
    plt.title("K-Means Clustering (2D PCA Projection)")
    plt.xlabel("Principal Component 1")
    plt.ylabel("Principal Component 2")
    plt.legend(title="Cluster", loc="upper right")
    plt.grid(True)
    plt.tight_layout()
    plt.show()

# -------------------------------
# Print Cluster Centers
# -------------------------------
def print_cluster_centers(model, feature_names):
    print("\n--- Cluster Centers (Standardized Values) ---")
    for i, center in enumerate(model.cluster_centers_):
        print(f"\nCluster {i}:")
        for name, val in zip(feature_names, center):
            print(f"  {name}: {val:.3f}")

# -------------------------------
# Silhouette Score Evaluation
# -------------------------------
def evaluate_silhouette_score(data_scaled, labels):
    if len(set(labels)) < 2:
        print("\nCannot compute silhouette score with less than 2 clusters.")
        return None
    score = silhouette_score(data_scaled, labels)
    print(f"\nSilhouette Score: {score:.3f} (range: -1 to 1; higher is better)")
    return score


# -------------------------------
# Main
# -------------------------------
if __name__ == "__main__":
    csv_file_path = "C:/Users/tbaguma/Downloads/2023_Green_Taxi_Trip_Data_20250702.csv"

    df = load_data(csv_file_path)

    if df is not None:
        perform_eda(df)

        columns, scaled_data, df_numeric = preprocess_data(df)

        if len(scaled_data) == 0:
            print("No data available for clustering. Exiting.")
        else:
            elbow_plot(scaled_data, max_k=10)

            k = 3
            model, cluster_labels = apply_kmeans(scaled_data, k)

            print_cluster_centers(model, columns)
            print(f"\nInertia (within-cluster sum of squares): {model.inertia_:.2f}")
            evaluate_silhouette_score(scaled_data, cluster_labels)

            visualize_clusters(scaled_data, cluster_labels)

            # Save results to CSV
            df_output = df_numeric.copy()
            df_output['Cluster'] = cluster_labels
            output_path = "C:/Users/tbaguma/Downloads/clustered_output.csv"
            df_output.to_csv(output_path, index=False)
            print(f"\nClustered data saved to: {output_path}")
