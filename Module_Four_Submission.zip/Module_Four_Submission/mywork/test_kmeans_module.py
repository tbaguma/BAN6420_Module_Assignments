#%%
import unittest
import pandas as pd
import numpy as np
import tempfile
import os

from module4_Kmeans import (
    load_data,
    preprocess_data,
    apply_kmeans,
    evaluate_silhouette_score
)

class TestKMeansModule(unittest.TestCase):

    def setUp(self):
        # Sample minimal DataFrame
        self.df = pd.DataFrame({
            'A': [1, 2, 3, 4, 5],
            'B': [5, 4, 3, 2, 1],
            'C': [10, 10, 10, 10, 10]
        })

    def test_load_data_success(self):
        # Create a temporary CSV file for testing
        with tempfile.NamedTemporaryFile(mode='w', suffix=".csv", delete=False) as tmp:
            tmp.write("A,B,C\n1,5,10\n2,4,10\n3,3,10")
            tmp_path = tmp.name

        try:
            df = load_data(tmp_path)
            self.assertIsInstance(df, pd.DataFrame)
            self.assertEqual(df.shape, (3, 3))
        finally:
            os.remove(tmp_path)

    def test_load_data_fail(self):
        df = load_data("non_existent_file.csv")
        self.assertIsNone(df)

    def test_preprocess_data(self):
        cols, scaled, numeric_df = preprocess_data(self.df)
        self.assertEqual(len(cols), 3)
        self.assertEqual(scaled.shape, (5, 3))
        self.assertIsInstance(numeric_df, pd.DataFrame)

    def test_apply_kmeans(self):
        _, scaled, _ = preprocess_data(self.df)
        model, labels = apply_kmeans(scaled, k=2)
        self.assertEqual(len(labels), scaled.shape[0])
        self.assertEqual(len(set(labels)), 2)

    def test_evaluate_silhouette_score(self):
        _, scaled, _ = preprocess_data(self.df)
        model, labels = apply_kmeans(scaled, k=2)
        score = evaluate_silhouette_score(scaled, labels)
        self.assertGreaterEqual(score, -1.0)
        self.assertLessEqual(score, 1.0)

    def test_preprocess_empty_df(self):
        empty_df = pd.DataFrame()
        cols, scaled, numeric_df = preprocess_data(empty_df)
        self.assertEqual(cols, [])
        self.assertTrue(isinstance(scaled, np.ndarray))
        self.assertEqual(scaled.size, 0)
        self.assertTrue(numeric_df.empty)

    def test_kmeans_single_cluster(self):
        _, scaled, _ = preprocess_data(self.df)
        model, labels = apply_kmeans(scaled, k=1)
        self.assertTrue(all(label == 0 for label in labels))


if __name__ == "__main__":
    unittest.main()

#%%
