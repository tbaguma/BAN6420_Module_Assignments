# K-Means Clustering Application

This Python application is designed using the PyCharm IDE and performs K-Means clustering on a given dataset (CSV format). It includes exploratory data analysis (EDA), pre-processing, optimal cluster determination using the Elbow method, cluster visualization using PCA, and evaluation using silhouette score. The results, including cluster assignments, are saved to a new CSV file. It also includes unit tests to validate core functions.

## Structure

kmeans_clustering/
│
├── main.py # Main script: full clustering pipeline
├── module4_Kmeans.py # Module containing reusable functions
├── test_module4_Kmeans.py # Unit tests for core functions
├── 2023_Green_Taxi_Trip_Data_20250702.csv # Input CSV file (example)
├── clustered_output.csv # Output CSV with cluster labels
└── README.md # Project documentation

## Features

- Load and validate CSV data.
- Perform EDA: data types, missing values, duplicates, correlation heatmap.
- Preprocess numeric features (drop sparse columns, impute missing, scale).
- Determine optimal `k` using Elbow method.
- Train a K-Means clustering model.
- Visualize clusters in 2D using PCA.
- Evaluate clustering with silhouette score.
- Export results with cluster labels to CSV.
- Unit tested for correctness and stability

## Requirements

Install the following Python libraries:

- pandas
- numpy
- matplotlib
- seaborn
- scikit-learn


## How to Use
1. Download the 2023_Green_Taxi_Trip_Data_20250702.csv from https://data.cityofnewyork.us/Transportation/2023-Green-Taxi-Trip-Data/peyi-gg4n/about_data
	Note - Filter by date 'lpep_pickup_datetime'
2. Copy the main.py script to your project directory.
3. Copy the unittest.py script into the same folder
3. Change your csv_file_path = "C:/Users/tbaguma/Downloads/2023_Green_Taxi_Trip_Data_20250702.csv" to the appropriate path
4. Run the script:

## Output Example
- Cluster Centers (Standardized Values)
- Silhouette Score:
- Correlation heatmap
- Elbow method plot
- PCA scatter plot with clusters
