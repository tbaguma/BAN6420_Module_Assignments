# Loading Required Libraries
library(readr)
library(zip)
library(ggplot2)

# Define paths
zip_file_path <- "C:/Users/tbaguma/cleaned_netflix_data.zip"
csv_file_name <- "cleaned_netflix_data.csv"

# Extract the CSV file from the zip
unzip(zip_file_path, files = csv_file_name, exdir = tempdir())
csv_file_path <- file.path(tempdir(), csv_file_name)

# Read the extracted CSV file
cleaned_data <- read_csv(csv_file_path)

# Display the first few rows
print(head(cleaned_data))

# Cleanup: Remove the extracted CSV file
file.remove(csv_file_path)

# Split 'listed_in' column into individual genres and count occurrences
genres_list <- unlist(strsplit(as.character(cleaned_data$listed_in), ", "))
genre_counts <- table(genres_list)

# Prepare genre_df for plotting
genre_df <- as.data.frame(genre_counts)
colnames(genre_df) <- c("Genre", "Frequency")
genre_df <- genre_df[order(genre_df$Frequency, decreasing = TRUE), ]

# Create the Genre Distribution Bar Plot
ggplot(genre_df, aes(x = Frequency, y = reorder(Genre, Frequency))) +
  geom_bar(stat = "identity", fill = "steelblue") +  # Create the bars
  labs(
    x = "Frequency", 
    y = "Genre", 
    title = "Most Watched Genres"
  ) +
  theme_minimal() +  # Theme cleaning
  theme(
    axis.text.y = element_text(size = 10),  # Adjusting size of y-axis labels
    plot.title = element_text(size = 14, face = "bold")  # Adjusting title size
  )

  